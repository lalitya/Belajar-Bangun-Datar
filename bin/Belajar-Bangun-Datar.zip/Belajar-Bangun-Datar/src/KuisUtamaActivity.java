package com.example.aplikasibdm;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class KuisUtamaActivity extends TabActivity{

	protected void onCreate(Bundle savedInstanceState) {
		// TODO AutoKuis-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.kuis_main);
		
		TabHost tabHost = getTabHost();
		
		//tab untuk kuis
		TabSpec kuisSpec = tabHost.newTabSpec("Kuis");
		kuisSpec.setIndicator("Kuis",getResources().getDrawable(R.drawable.about_biru));
		Intent kuisIntent = new Intent(this,KuisActivity.class);
		kuisSpec.setContent(kuisIntent); 
		
		//tab untuk hasil
		TabSpec hasilSpec = tabHost.newTabSpec("Hasil");
		hasilSpec.setIndicator("Hasil",getResources().getDrawable(R.drawable.about_merah));
		Intent hasilIntent = new Intent(this,HasilActivity.class);
		hasilSpec.setContent(hasilIntent); 
		
		tabHost.addTab(kuisSpec);
		tabHost.addTab(hasilSpec);
	}
	
}
