package com.example.aplikasibdm;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class KuisActivity extends Activity{
	static Soal lingkaran, persegi, layang, Ketupat,jajargenjang, segitiga, trapesium;
	static TextView jawab, lblKuis, lblKebenaran;
	static RadioButton jawaban, buttonA, buttonB, buttonC, buttonD;
	static RadioGroup group;
	static int selectedId;
	static int nilai=0;
	static Button submit;
	int indexSoal = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO AutoKuis-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.kuis);
		lblKuis = (TextView) findViewById(R.id.lblSoal);
		buttonA = (RadioButton) findViewById(R.id.buttonPilihanA);
		buttonB = (RadioButton) findViewById(R.id.buttonPilihanB);
		buttonC = (RadioButton) findViewById(R.id.buttonPilihanC);
		buttonD = (RadioButton) findViewById(R.id.buttonPilihanD);
		jawab = (TextView) findViewById(R.id.textView1);
		group = (RadioGroup) findViewById(R.id.radioGroup1);
		
		submit = (Button) findViewById(R.id.button_submit);
		lblKebenaran = (TextView) findViewById(R.id.lblKebenaran);
		if (PilihanKuisActivity.idKuis == 1){
			buatSoalPersegi();
			masukanSoal(persegi, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 2){
			buatSoalSegitiga();
			masukanSoal(segitiga, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 3){
			buatSoalKetupat();
			masukanSoal(Ketupat, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 4){
			buatSoalTrapesium();
			masukanSoal(trapesium, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 5){
			buatSoalJajargenjang();
			masukanSoal(jajargenjang, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 6){
				buatSoalLayang();
				masukanSoal(layang, indexSoal);
		}else if(PilihanKuisActivity.idKuis == 7){
			buatSoalLingkaran();
			masukanSoal(lingkaran,indexSoal);
		}
		
	}
	
	public static void masukanSoal(Soal soal, int i){
		lblKuis.setText(soal.getSoal()[i]);
		buttonA.setText(soal.getPilihanA()[i]);
		buttonB.setText(soal.getPilihanB()[i]);
		buttonC.setText(soal.getPilihanC()[i]);
		buttonD.setText(soal.getPilihanD()[i]);
		jawab.setText(soal.getJawaban()[i]);
	}
	public static void buatSoalPersegi(){
		persegi = new Soal();
		String[] soal = {
				"1.	Diketahui sisi persegi 10cm. Hitunglah keliling persegi...",
				"2.	Diketehui sisi persegi 14cm. Hitunglah luas persegi tersebut...",
				"3.	Berapakah sisi persegi, jika diketahui keliling persegi tersebut 28cm...",
				"4.	Berapakah sisi persegi, jika diketahui luas persegi 64cm2...",
				"5. Lahan milik Pak Hasan yang berbentuk persegi akan ditanami pohon cemara di sekeliling lahan. Jika jarang antara tanaman yang satu dengan yang lain 2 meter, berapa banyak pohon cemara yang akan ditanam...",
				"6. Hitunglah jumlah sisi dari empat persegi...",
				"7.	Terdapat dua buah persegi. Luas persegi S dua kali lipat dari luas lingkaran V. Jika diketahui luas persegi S 1250cm2. berapa jari-jari persegi V...",
				"8.	T8.	Berikut ini manakah keterangan yang SALAH mengenai persegi...",
				"9.	Berikut ini manakah yang merupakan rumus menghitung keliling persegi...",
				"10. Hitunglah berapa banyak persegi kecil yang dapat disusun untuk membangun persegi besar yang memiliki luas 144cm2 . Jika diketahui sisi persegi kecilnya 4cm..."
		};
		
		String[] pilihanA = {
				"20cm",
				"28cm",
				"4 cm",
				"4 cm",
				"8 cm",
				"4 sisi",
				"12 cm",
				"Persegi memiliki dua sudut",
				"phi x r2",
				"9 persegi kecil"
		};
	
		String[] pilihanB = {
				"40 cm",
				"56 cm",
				"7 cm",
				"8 cm2",
				"9 cm",
				"8 sisi",
				"25 detik",
				"Persegi memiliki empat sisi",
				"(2 x panjang) + (2 x lebar)",
				"10 persegi kecil"
				
		};
		
		String[] pilihanC = {
				"40 cm2",
				"196 cm2",
				"56 cm2",
				"16 cm",
				"11 pohon",
				"12 sisi",
				"37 cm",
				"Persegi memiliki sisi yang sama panjang",
				"4 x sisi",
				"12 persegi kecil"
				
		};
		
		String[] pilihanD = {
				"100 cm",
				"196 cm",
				"196 cm2",
				"128 cm",
				"12 pohon",
				"16 sisi",
				"50 cm",
				"Persegi memiliki sudut yang sama besar",
				"sisi x sisi",
				"16 persegi kecil"
				
		};
		
		String[] jawaban = {
				"40 cm",
				"196 cm2",
				"7 cm",
				"8 cm",
				"11 pohon",
				"16 sisi",
				"25 cm",
				"Persegi memiliki dua sudut",
				"4 x sisi",
				"9 persegi kecil"
				
		};
		persegi.setSoal(soal);
		persegi.setPilihanA(pilihanA);
		persegi.setPilihanB(pilihanB);
		persegi.setPilihanC(pilihanC);
		persegi.setPilihanD(pilihanD);
		persegi.setJawaban(jawaban);
		
	}

	public static void buatSoalSegitiga(){
		segitiga = new Soal();
		String[] soal = {
				"1.	Diketahui tinggi segitiga 10cm dan alasnya 5cm. Hitunglah luas segitiga...",
				"2.	Berapakah tinggi segitiga, jika diketahui alas segitiga 8cm dan luasnya 32cm2...",
				"3.	Berapakah alas segitiga, jika diketahui tinggi segitiga 3cm dan luasnya 30cm2...",
				"4.	Diketahui keliling segitiga sama sisi adalah 45cm. Berapakah sisi dari segitiga tersebut...",
				"5. Bangun yang mempunyai 3 sisi dan 3 sudut adalah...",
				"6. Berikut ini manakah yang merupakan rumus menghitung luas segitiga...",
				"7.	Terdapat dua segitiga. Luas segitiga A setengah dari luas segitiga B. Jika diketahui luas segitiga A 15cm2, tinggi segitiga B 5cm. Berapa alas segitiga B...",
				"8.	Berikut ini manakah keterangan yang BENAR mengenai persegi...",
				"9.	Keliling segitiga sama sisi adalah 150cm. Berapakah panjang sisi segitiga tersebut...",
				"10. Segitiga siku-siku memiliki sudut sebesar�"
		};
		
		String[] pilihanA = {
				"15 cm",
				"2 cm",
				"10 cm",
				"10 cm",
				"Segitiga",
				"phi x r2",
				"12 cm",
				"Segitiga memiliki empat sisi",
				"25 cm",
				"30 derajat"
		};
	
		String[] pilihanB = {
				"25 cm2",
				"4 cm",
				"20 cm",
				"45 cm2",
				"Persegi",
				"(2 x panjang) + (2 x lebar)",
				"14 cm",
				"Segitiga memiliki sisi yang sama panjang",
				"50 cm",
				"45 derajat"
				
		};
		
		String[] pilihanC = {
				"35 cm2",
				"8 cm2",
				"60 cm2",
				"15 cm",
				"beah ketupat",
				"(alas�tinggi)/2",
				"24 cm",
				"Segitiga memiliki sudut yang sama besar",
				"75 cm",
				"60 derajat"
				
		};
		
		String[] pilihanD = {
				"50 cm2",
				"16 cm",
				"90 cm",
				"135 cm2",
				"Lingkaran",
				"4 x sisi",
				"28 cm",
				"	Segitiga memiliki rumus hitung luas: (alas�tinggi)/2",
				"150 cm",
				"90 derajat"
				
		};
		
		String[] jawaban = {
				"25 cm2",
				"8 cm",
				"20 cm",
				"15 cm",
				"Segitiga",
				"(alas �tinggi)/2",
				"12 cm",
				"	Segitiga memiliki rumus hitung luas: (alas �tinggi)/2",
				"50 cm",
				"90 derajat"
				
		};
		segitiga.setSoal(soal);
		segitiga.setPilihanA(pilihanA);
		segitiga.setPilihanB(pilihanB);
		segitiga.setPilihanC(pilihanC);
		segitiga.setPilihanD(pilihanD);
		segitiga.setJawaban(jawaban);
		
	}
	
	public static void buatSoalTrapesium(){
		trapesium = new Soal();
		String[] soal = {
				"1.	Jumlah sisi bangun trapesium adalah�",
				"2.	Berikut ini manakah keterangan yang BENAR mengenai trapesium...",
				"3.	Putri menggambar sebuah perahu pada kertas gambar. Perahu tersebut berbentuk trapesium sama kaki dengan panjang sisi-sisi sejajarnya 12cm dan 7 cm, sedangkan tingginya 8cm. Berapa luas perahu yang digambar Putri...",
				"4.	Jika diketahui luas trapesium 306cm2, dengan sisi yang sejajar 10cm dan 26cm. Berapakah tinggi dari trapesium  tersebut...",
				"5. Jika diketahui sisi yang sejajar dari suatu trapesium adalah 7cm dan 3cm, serta tinggi dari trapesium tersebut adalah 5cm. Berapakah luas trapesium tersebut...",
				"6. Manakah berikut ini yang merupakan rumus menghitung luas trapesium...",
				"7.	Berikut ini manakah keterangan yang BENAR mengenai trapesium...",
				"8.	Sebidang tanah berbentuk trapesium. Panjang sisi-sisi yang sejajar masing-masing 58m dan 42m, sedangkan jarak antara kedua sisi yang sejajar tersebut adakah 37m. Berapa meter persegi luas tanah tersebut...",
				"9. Permukaan atap rumah P. Dedi berbentuk trapesium sama kaki . Tinggi atap tersebut adalah 4 m sedangkan sisi ujung atas atap tersebut sepanjang  15 m dan sisi ujung bawah atap 18m. Berapa luas atap rumah P. Dedi...",
				"10. Berapakah keliling trapesium dengan sisi 20 cm dan 5 cm, sisi miring 12 cm, adalah..."
		};
		
		String[] pilihanA = {
				"2 sisi",
				"Trapesium memiliki empat sisi yang sama panjang",
				"76 cm2",
				"8.5 cm",
				"5 cm2",
				"sisi x sisi",
				"Trapesium memiliki empat sisi yang sama panjang",
				"3700 m2",
				"66 m2",
				"35 cm",
		};
	
		String[] pilihanB = {
				"4 sisi",
				"Trapesium memiliki sisi alas yang sejajar dengan sisi atas",
				"13.5 cm2",
				"17 cm",
				"15 cm2",
				"phi�r�r",
				"Trapesium memiliki sisi alas yang sejajar dengan sisi atas",
				"3800 m2",
				"123 m2",
				"37 cm"
				
		};
		
		String[] pilihanC = {
				"3 sisi",
				"Trapesium memiliki sudut-sudut yang sama besar",
				"152 cm2",
				"270 cm",
				"25 cm2",
				"(Jumlah sisi sejajar � tinggi)/2",
				"Trapesium memiliki sudut-sudut yang sama besar",
				"4000 m2",
				"132 m2",
				"45 cm"
				
		};
		
		String[] pilihanD = {
				"6 sisi",
				"Trapesium memiliki rumus hitung luas: sisi x sisi",
				"672 cm2",
				"72.25 cm",
				"35 cm2",
				"(Alas � tinggi)/2",
				"Trapesium memiliki rumus hitung luas: sisi x sisi",
				"3700 m2",
				"264 m2",
				"49 cm"
				
		};
		
		String[] jawaban = {
				"4 sisi",
				"Trapesium memiliki sisi alas yang sejajar dengan sisi atas",
				"76 cm2",
				"17 cm",
				"25 cm2",
				"(Jumlah sisi sejajar � tinggi)/2",
				"Trapesium memiliki sisi alas yang sejajar dengan sisi atas",
				"3700 m2",
				"alas �tinggi",
				"49 cm"
				
		};
		trapesium.setSoal(soal);
		trapesium.setPilihanA(pilihanA);
		trapesium.setPilihanB(pilihanB);
		trapesium.setPilihanC(pilihanC);
		trapesium.setPilihanD(pilihanD);
		trapesium.setJawaban(jawaban);
		
	}


	public static void buatSoalJajargenjang(){
		jajargenjang = new Soal();
		String[] soal = {
				"1.	Diketahui tinggi jajargenjang 10cm dan alasnya 5cm. Hitunglah luas jajargenjang...",
				"2.	Berapakah tinggi jajargenjang, jika diketahui alas jajargenjang 8cm dan luasnya 32cm2...",
				"3.	Berapakah alas jajargenjang, jika diketahui tinggi jajargenjang 3cm dan luasnya 30cm2...",
				"4.	Berikut ini manakah keterangan yang BENAR mengenai jajar genjang...",
				"5. Berapa sisi dari jajar genjang...",
				"6. Berapakan keliling dan luas dari jajar genjang jika diketahui salah satu sisi = 3.5 m dan tinggi jajar genjangnya = 4 m, adalah...",
				"7.	Diketahui luas jajar genjang 125cm2 dan tingginya 25cm. Berapakah panjang salah satu sisi jajar genjang tersebut...",
				"8.	Diketahui taman yang berbentuk jajar genjang dengan panjang tiap sisinya 40m dan 20m. Aldo ingin berolahraga lari mengelilinya. Seberapa jauh Aldo akan berlari...",
				"9. Bagaimana cara menghitung keliling jajar genjang...",
				"10. Tuliskan rumus luas dari bangun jajar genjang..."
		};
		
		String[] pilihanA = {
				"15 cm",
				"4 cm",
				"10 cm",
				"Jajar genjang memiliki empat sisi yang sama panjang",
				"4 sisi",
				"14 cm dan 14 cm2",
				"5 cm",
				"60 m",
				"sisixsisi",
				"4 x sisi"
		};
	
		String[] pilihanB = {
				"15 cm2",
				"4 cm2",
				"10 cm2",
				"Jajar genjang memiliki sudut-sudut yang sama besar",
				"8 sisi",
				"14cm dan 15cm2",
				"7 cm",
				"80 m",
				"alas �tinggi",
				"panjang x lebar"
				
		};
		
		String[] pilihanC = {
				"50 cm",
				"8 cm",
				"90 cm",
				"Jajar genjang  memiliki rumus hitung luas: sisi x sisi",
				"12 sisi",
				"15cm dan 15cm2",
				"8 cm",
				"120 m",
				"(sisi �sisi)/2",
				"Jumlah sisi sejajar x tinggi"
				
		};
		
		String[] pilihanD = {
				"50 cm2",
				"8 cm2",
				"90 cm2",
				"Jajar genjang memiliki  sisi-sisi dan sudut-sudut yang berbeda",
				"16 sisi",
				"15cm dan 14cm2",
				"10 cm",
				"800 m",
				"(alas �tinggi)/2",
				"16 sisi"
				
		};
		
		String[] jawaban = {
				"50 cm",
				"4 cm",
				"10 cm",
				"Jajar genjang memiliki  sisi-sisi dan sudut-sudut yang berbeda",
				"4 sisi",
				"15cm dan 14cm2",
				"5 cm",
				"120 m",
				"alas �tinggi",
				"16 sisi"
				
		};
		jajargenjang.setSoal(soal);
		jajargenjang.setPilihanA(pilihanA);
		jajargenjang.setPilihanB(pilihanB);
		jajargenjang.setPilihanC(pilihanC);
		jajargenjang.setPilihanD(pilihanD);
		jajargenjang.setJawaban(jawaban);
		
	}

	public static void buatSoalKetupat(){
		Ketupat = new Soal();
		String[] soal = {
				"1. Hitunglah luas bangun belah ketupat, jika diketahui diagonalnya 2 cm...",
				"2.	Berikut ini manakah keterangan yang BENAR mengenai bangun belah ketupat...",
				"3.	Hitunglah luas bangun belah ketupat, jika diketahui diagonalnya 4 cm...",
				"4.	Berapakah diagonal bangun belah ketupat, jika luasnya 2048 cm2...",
				"5.	Nenek memiliki kue yang berbentuk belah ketupat, kue tersebut akan dibagikan pada empat cucunya. Jika diketahui diagonal kue tersebut 10 cm, berapa bagian luas yang diperoleh masing-masing cucunya...",
				"6.	Ibu memiliki 8 tisyu yang berbentuk belah ketupat. Ukuran tisyu-tisyu tersebut sama besar. Jika diketahui diagonal tisyu tersebut 4 cm, berapakah luas 8 tisyu Ibu...",
				"7.	Manakah berikut ini yang merupakan rumus menghitung luas belah ketupat...",
				"8.	Bangun berikut yang rumus hitung luasnya dapat digunakan untuk menghitung luas bangun belah ketupat adalah...",
				"9.	Berapakah keliling belahketupat jika sisinya 8?",
				"10.Isa adalah ketua regu pramuka. Ia memiliki kertas berbentuk belah ketupat. Kertas tersebut akan dipotong-potong dan dibagikan pada setiap anggota untuk mengisi nama anggota. Jika diketahui diagonal kertas isa 20cm dan tiap anggota  mendapat bagian seluas 5 cm2. Berapakah anggota Isa..."
		};
		
		String[] pilihanA = {
				"4 cm2",
				"Belah ketupat memiliki sisi-sisi yang sama panjang",
				"4 cm2",
				"8 cm",
				"10 cm",
				"8 cm2",
				"p � r �r",
				"Persegi",
				"8 cm",
				"15 orang"
		};
	
		String[] pilihanB = {
				"8 cm2",
				"Belah ketupat memiliki empat diagonal",
				"8 cm2",
				"32 cm",
				"12.5 cm",
				"16 cm2",
				"p/2  � d",
				"Trapesium",
				"32 cm",
				"20 orang"
			};
		
		String[] pilihanC = {
				"16 cm2",
				"Belah ketupat memiliki sudut yang tidak sama besar",
				"16 cm2",
				"64 cm",
				"25 cm",
				"64 cm2",
				"(Jumlah sisi sejajar � tinggi)/2",
				"Layang-layang",
				"64 cm",
				"40 orang"
		};
		
		String[] pilihanD = {
				"64 cm2",
				"Belah ketupat memiliki rumus hitung (diagonal 1)/(diagonal 2)",
				"64 cm2",
				"125 cm",
				"50 cm",
				"256 cm2",
				"1/2  � d^2",
				"Jajar genjang",
				"72 cm",
				"60 orang"
		};
		
		String[] jawaban = {
				"4 cm2",
				"Belah ketupat memiliki sisi-sisi yang sama panjang",
				"8 cm2",
				"64 cm",
				"12.5 cm",
				"64 cm2",
				"1/2  � d^2",
				"Layang-layang",
				"32 cm",
				"40 orang"
				
		};
		Ketupat.setSoal(soal);
		Ketupat.setPilihanA(pilihanA);
		Ketupat.setPilihanB(pilihanB);
		Ketupat.setPilihanC(pilihanC);
		Ketupat.setPilihanD(pilihanD);
		Ketupat.setJawaban(jawaban);
		
	}

	
	public static void buatSoalLayang(){
		layang = new Soal();
		String[] soal = {
				"1.	Rizki sedang bermain layang-layang. Layang-layang Rizki sangat besar, ukuran salah satu diagonalnya adalah 0.5 m dan luasnya 2000cm2. Berapa cm panjang diagonal yang lain...",
				"2.	Nanda akan membuat layang-layang dari dua bilah bambu yang panjangnya 21 cm dan 24 cm. Perpotongan kedua bilah membagi bilah yang panjangnya 21 cm menjadi dua bagian, yaitu 16cm dan 5cm dan bilah yang panjangnya 24cm menjadi 12cm dan 12cm. Berapa luas layang-layang yang terbentuk...",
				"3.	Hitunglah luas layang-layang yang diagonalnya 2 m dan5 m...",
				"4.	Sebuah layang-layang memiliki luas 1620 cm2 dengan salah satu diagonalnya 72 cm. Berapa cm diagonal yang lainnya...",
				"5.	Manakah berikut ini yang merupakan rumus menghitung luas layang-layang...",
				"6. Berikut ini manakah keterangan yang SALAH mengenai bangun layang-layang...",
				"7.	Sebuah layang-layang memiliki luas 1620 cm2 dengan salah satu diagonalnya 72 cm. Berapa cm diagonal yang lainnya...",
				"8.	Hitunglah keliling bangun layang-layang, jika diketahui dua sisi miringnya yang berbeda  adalah 5 cm dan 14cm...",
				"9.	Hitunglah luas layang-layang yang diagonalnya 2 m dan5 m...",
				"10. Hitunglah diagonal ke-dua dari layang-layang yang memiliki luas 1100 cm2 dan diagonal yang lain 11 cm..."
		};
		
		String[] pilihanA = {
				"4m",
				"125 cm2",
				"5 m2",
				"22.5 cm",
				"p � r �r",
				"Layang-layang memiliki empat sisi",
				"22.5 cm",
				"19 cm",
				"131.88 cm",
				"100 cm"
		};
	
		String[] pilihanB = {
				"8m",
				"152 cm2",
				"10 m2",
				"22 cm",
				"(d1 x d2)/2",
				"Layang-layang memiliki sisi-sisi yang sama panjang",
				"22 cm",
				"27 cm",
				"10 m2",
				"110 cm"
			};
		
		String[] pilihanC = {
				"4cm",
				"252 cm2",
				"15 m2",
				"22 cm",
				"(d1 x d2)/2",
				"Layang-layang memiliki dua diagonal",
				"22 cm",
				"38 cm",
				"15 m2",
				"200 cm"
		};
		
		String[] pilihanD = {
				"8cm",
				"255 cm2",
				"25 m2",
				"72 cm",
				"(alas x tinggi)/2",
				"Layang-layang memiliki rumus hitung luas: 1/2�d_1�d_2",
				"72 cm",
				"50 cm",
				"25 m2",
				"220 cm"
		};
		
		String[] jawaban = {
				"8 cm",
				"252 cm2",
				"5 m2",
				"45 cm",
				"(d1 x d2)/2",
				"Layang-layang memiliki sisi-sisi yang sama panjang",
				"45 cm",
				"38 cm",
				"5 m2",
				"200 cm"
				
		};
		layang.setSoal(soal);
		layang.setPilihanA(pilihanA);
		layang.setPilihanB(pilihanB);
		layang.setPilihanC(pilihanC);
		layang.setPilihanD(pilihanD);
		layang.setJawaban(jawaban);
		
	}

	public static void buatSoalLingkaran(){
		lingkaran = new Soal();
		String[] soal = {
				"1.	Diketahui jari-jari lingkaran 7cm. Hitunglah keliling lingkaran...",
				"2.	Diketehui jari-jari lingkaran 14cm. Hitunglah luas lingkaran...",
				"3.	Berapakah keliling lingkaran, jika diketahui diameter lingkaran tersebut 7cm...",
				"4.	Berapakah luas lingkaran, jika diketahui diameter lingkaran tersebut 14cm...",
				"5.	Berapakah jari-jari lingkaran, jika diketahui diameternya 50cm...",
				"6. Berapakah jumlah sisi lingkaran",
				"7.	Diketahui jari-jari taman yang berbentuk lingkaran sepanjang 14 meter. Andi ingin mengelilingi taman tersebut dengan waktu 2 detik/meter. Hitunglah berapa lama waktu yang dibutuhkan Andi untuk mengelilingi taman tersebut...",
				"8.	Terdapat balon berbentuk lingkaran dengan jari-jari 4.2cm, berapa jumlah luas dari 2 buah balon...",
				"9.	Hitunglah keliling topi bundar yang memiliki diameter 42cm...",
				"10. Terdapat dua buah lingkaran. Luas lingkaran A dua kali lipat dari luas lingkaran B. Jika diketahui luas lingkaran A 4923.52cm2. berapa jari-jari lingkaran B..."
		};
		
		String[] pilihanA = {
				"44 cm",
				"44 cm",
				"44 cm",
				"44 cm",
				"25 cm",
				"1 sisi",
				"1223 detik",
				"131.88 cm2",
				"131.88 cm",
				"2461.76 cm2"
		};
	
		String[] pilihanB = {
				"154 cm",
				"616 cm",
				"22 cm",
				"44 cm2",
				"157 cm",
				"2 sisi",
				"1212 detik",
				"553.9 cm2",
				"131.88 cm2",
				"28 cm"
				
		};
		
		String[] pilihanC = {
				"44 cm2",
				"44 cm2",
				"44 cm2",
				"154 cm",
				"157 cm2",
				"3 sisi",
				"1232 detik",
				"110.78 cm2",
				"553.9 cm",
				"28 cm2"
				
		};
		
		String[] pilihanD = {
				"154 cm2",
				"616 cm2",
				"22 cm2",
				"154 cm2",
				"1962.5 cm2",
				"4 sisi",
				"1234 detik",
				"166.17 cm2",
				"553.9 cm2",
				"14 cm"
				
		};
		
		String[] jawaban = {
				"44 cm",
				"616 cm2",
				"22 cm",
				"154 cm2",
				"25 cm",
				"1 sisi",
				"1232 detik",
				"110.78 cm2",
				"131.88 cm",
				"28 cm"
				
		};
		lingkaran.setSoal(soal);
		lingkaran.setPilihanA(pilihanA);
		lingkaran.setPilihanB(pilihanB);
		lingkaran.setPilihanC(pilihanC);
		lingkaran.setPilihanD(pilihanD);
		lingkaran.setJawaban(jawaban);	
	}
	
	public void submit(View v){
		
		if(indexSoal<9){
			selectedId = group.getCheckedRadioButtonId();
			jawaban = (RadioButton)findViewById(selectedId);
			
			if (jawaban.getText().equals(jawab.getText())){
				lblKebenaran.setText("No. " + (indexSoal+1)+": Benar");
				nilai++;
			}else {
				lblKebenaran.setText("No. " + (indexSoal+1)+": Salah");
			}
			indexSoal++;
			if (PilihanKuisActivity.idKuis == 1){
				masukanSoal(persegi, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 2){
				masukanSoal(segitiga, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 3){
				masukanSoal(Ketupat, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 4){
				masukanSoal(trapesium, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 5){
				masukanSoal(jajargenjang, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 6){
					masukanSoal(layang, indexSoal);
			}else if(PilihanKuisActivity.idKuis == 7){
				masukanSoal(lingkaran,indexSoal);
			}
		}else if(indexSoal==9){
			if (jawaban.getText().equals(jawab.getText())){
				lblKebenaran.setText("No. " + (indexSoal+1)+": Benar");
				nilai++;
			}else {
				lblKebenaran.setText("No. " + (indexSoal+1)+": Salah");
			}
			indexSoal++;
		}else {
			Intent i = new Intent();
			i.setClass(this, TampilanNilaiActivity.class);
	        startActivity(i);
		}
	}
}

