package com.example.aplikasibdm;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class HasilActivity extends Activity {
	
	protected void onCreate(Bundle savedInstanceState) {
		// TODO AutoKuis-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tampilan_nilai);
	}
}
