package com.example.aplikasibdm;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class TampilanNilaiActivity extends Activity{
	TextView nilai;
	String nil;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tampilan_nilai);
		nilai = (TextView) findViewById(R.id.textView2);
		nil = KuisActivity.nilai + "0";
		nilai.setText(nil);
	}
	
	
}
