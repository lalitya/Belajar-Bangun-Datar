package com.example.aplikasibdm;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PilihanKuisActivity extends Activity{
	public  static int idKuis=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO AutoKuis-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pilihan_kuis);
	}
 
	public void toKuisPersegi(View v){
		PilihanKuisActivity.idKuis = 1 ;
		masukMateri();

	}

	
	public void toKuisSegitiga(View v){
		PilihanKuisActivity.idKuis = 2 ;
		masukMateri();
	}
	
	
	public void toKuisBelahKetupat(View v){
		PilihanKuisActivity.idKuis = 3 ;
		masukMateri();
	}
	
	public void toKuisTrapesium(View v){
		PilihanKuisActivity.idKuis = 4 ;
		masukMateri();
	}
	
	public void toKuisJajarGenjang(View v){
		PilihanKuisActivity.idKuis = 5 ;
		masukMateri();
	}
	
	public void toKuisLayanglayang(View v){
		PilihanKuisActivity.idKuis = 6 ;
		masukMateri();
	}	
	
	public void toKuisLingkaran(View v){
		PilihanKuisActivity.idKuis = 7 ;
		masukMateri();
	}
	
	public void masukMateri(){
		Intent i = new Intent();
		i.setClass(this, KuisActivity.class);
        startActivity(i);
	}
}
