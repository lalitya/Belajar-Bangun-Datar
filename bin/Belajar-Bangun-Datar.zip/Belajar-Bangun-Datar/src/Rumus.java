package com.example.aplikasibdm;

public interface Rumus {
	double getVolume();
	double getLuas();
}
