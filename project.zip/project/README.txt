DILARANG!!
   Menuliskan nama anggota kelompok
   Menuliskan ini sebagai tugas rpl

Yang dituliskan
   Deskripsi umum perangkat lunak yang dibuat.
   URL download aplikasi.
   Panduan Instalasi (singkat).
   Contact Person.